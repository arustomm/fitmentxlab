'use client'

interface ShopFiltersProps {
  selectedCategory: string
  onCategoryChange: (category: string) => void
  sortBy: string
  onSortChange: (sort: string) => void
}

export function ShopFilters({
  selectedCategory,
  onCategoryChange,
  sortBy,
  onSortChange,
}: ShopFiltersProps) {
  const categories = ['All', 'Wheels', 'Tires', 'Suspension']
  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'price-low', label: 'Price: Low to High' },
    { value: 'price-high', label: 'Price: High to Low' },
    { value: 'name', label: 'Name A-Z' },
  ]

  return (
    <div className="space-y-6">
      {/* Categories */}
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">Categories</h3>
        <div className="space-y-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => onCategoryChange(category)}
              className={`block w-full text-left px-4 py-2 rounded-lg transition-colors ${
                selectedCategory === category
                  ? 'bg-chili-red text-white'
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Sort */}
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">Sort By</h3>
        <select
          value={sortBy}
          onChange={(e) => onSortChange(e.target.value)}
          className="w-full px-4 py-2 rounded-lg border border-gray-600 bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-chili-red focus:border-transparent"
        >
          {sortOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      {/* Price Range */}
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">Price Range</h3>
        <div className="space-y-2 text-sm">
          <div className="text-gray-300">
            <span className="font-medium">Wheels:</span> $799 - $1,599
          </div>
          <div className="text-gray-300">
            <span className="font-medium">Tires:</span> $299 - $389
          </div>
          <div className="text-gray-300">
            <span className="font-medium">Suspension:</span> $2,599 - $2,899
          </div>
        </div>
      </div>

      {/* Brands */}
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">Brands</h3>
        <div className="space-y-2 text-sm text-gray-300">
          <div>KG1 Forged</div>
          <div>JTX Forged</div>
          <div>American Force</div>
          <div>Nitto</div>
          <div>BDS Suspension</div>
          <div>Fuel Off-Road</div>
        </div>
      </div>
    </div>
  )
}

