// Static product data for immediate deployment
export const staticProducts = [
  {
    id: 1,
    name: "KG1 Forged Victor KC010",
    slug: "kg1-forged-victor-kc010",
    description: "Premium forged wheel with aggressive styling and lightweight construction. Perfect for lifted trucks and performance applications.",
    price: 899,
    compareAtPrice: 1099,
    category: "Wheels",
    brand: "KG1 Forged",
    imageUrl: "/images/products/kg1-victor.jpg",
    inStock: true,
    stockQuantity: 12,
    featured: true,
    specifications: {
      size: "20x10",
      bolt_pattern: "6x139.7",
      offset: "-24mm",
      backspacing: "4.25\"",
      load_rating: "3200 lbs",
      finish: "Matte Black"
    }
  },
  {
    id: 2,
    name: "KG1 Forged Primacy",
    slug: "kg1-forged-primacy",
    description: "Elegant forged wheel design with premium finish and exceptional strength for luxury trucks.",
    price: 1299,
    compareAtPrice: 1499,
    category: "Wheels",
    brand: "KG1 Forged",
    imageUrl: "/images/products/kg1-primacy.png",
    inStock: true,
    stockQuantity: 8,
    featured: true,
    specifications: {
      size: "22x12",
      bolt_pattern: "6x135",
      offset: "-44mm",
      backspacing: "3.75\"",
      load_rating: "3500 lbs",
      finish: "Gloss Black Machined"
    }
  },
  {
    id: 3,
    name: "KG1 Forged Checkmate",
    slug: "kg1-forged-checkmate",
    description: "Bold checkered pattern forged wheel for those who want to make a statement.",
    price: 1199,
    compareAtPrice: 1399,
    category: "Wheels",
    brand: "KG1 Forged",
    imageUrl: "/images/products/kg1-checkmate.jpg",
    inStock: true,
    stockQuantity: 6,
    featured: false,
    specifications: {
      size: "20x12",
      bolt_pattern: "8x170",
      offset: "-44mm",
      backspacing: "3.75\"",
      load_rating: "4000 lbs",
      finish: "Matte Black"
    }
  },
  {
    id: 4,
    name: "JTX 404 Dually",
    slug: "jtx-404-dually",
    description: "Heavy-duty dually wheel designed for maximum strength and style on dual rear wheel trucks.",
    price: 799,
    compareAtPrice: 999,
    category: "Wheels",
    brand: "JTX",
    imageUrl: "/images/products/jtx-404-dually.png",
    inStock: true,
    stockQuantity: 16,
    featured: false,
    specifications: {
      size: "19.5x6.75",
      bolt_pattern: "8x200",
      offset: "143mm",
      backspacing: "8.375\"",
      load_rating: "4000 lbs",
      finish: "Gloss Black"
    }
  },
  {
    id: 5,
    name: "JTX Vanquish",
    slug: "jtx-vanquish",
    description: "Aggressive split-spoke design with deep concave profile for modern truck builds.",
    price: 1099,
    compareAtPrice: 1299,
    category: "Wheels",
    brand: "JTX",
    imageUrl: "/images/products/jtx-vanquish.png",
    inStock: true,
    stockQuantity: 10,
    featured: true,
    specifications: {
      size: "22x10",
      bolt_pattern: "6x139.7",
      offset: "0mm",
      backspacing: "5.5\"",
      load_rating: "3200 lbs",
      finish: "Satin Black"
    }
  },
  {
    id: 6,
    name: "JTX D204",
    slug: "jtx-d204",
    description: "Classic mesh design with modern engineering for the perfect blend of style and performance.",
    price: 949,
    compareAtPrice: 1149,
    category: "Wheels",
    brand: "JTX",
    imageUrl: "/images/products/jtx-d204.png",
    inStock: true,
    stockQuantity: 14,
    featured: false,
    specifications: {
      size: "20x9",
      bolt_pattern: "5x150",
      offset: "18mm",
      backspacing: "6.2\"",
      load_rating: "3000 lbs",
      finish: "Gloss Black Machined"
    }
  },
  {
    id: 7,
    name: "American Force Independence SS",
    slug: "american-force-independence-ss",
    description: "Forged aluminum wheel with patriotic styling and unmatched strength for heavy-duty applications.",
    price: 1599,
    compareAtPrice: 1799,
    category: "Wheels",
    brand: "American Force",
    imageUrl: "/images/products/american-force-1.jpg",
    inStock: true,
    stockQuantity: 4,
    featured: true,
    specifications: {
      size: "24x14",
      bolt_pattern: "8x180",
      offset: "-76mm",
      backspacing: "2.5\"",
      load_rating: "4500 lbs",
      finish: "Polished"
    }
  },
  {
    id: 8,
    name: "American Force Blade SS",
    slug: "american-force-blade-ss",
    description: "Razor-sharp spoke design with premium forged construction for ultimate performance.",
    price: 1499,
    compareAtPrice: 1699,
    category: "Wheels",
    brand: "American Force",
    imageUrl: "/images/products/american-force-2.png",
    inStock: true,
    stockQuantity: 6,
    featured: false,
    specifications: {
      size: "22x12",
      bolt_pattern: "8x165.1",
      offset: "-44mm",
      backspacing: "3.75\"",
      load_rating: "4000 lbs",
      finish: "Black Machined"
    }
  },
  {
    id: 9,
    name: "Nitto Ridge Grappler",
    slug: "nitto-ridge-grappler",
    description: "Hybrid all-terrain tire combining the best of mud and all-terrain performance.",
    price: 389,
    compareAtPrice: 449,
    category: "Tires",
    brand: "Nitto",
    imageUrl: "/images/products/nitto-ridge-grappler-tire.png",
    inStock: true,
    stockQuantity: 24,
    featured: true,
    specifications: {
      size: "35x12.50R20",
      load_index: "121",
      speed_rating: "Q",
      tread_depth: "18.5/32\"",
      max_load: "3197 lbs",
      max_pressure: "80 PSI"
    }
  },
  {
    id: 10,
    name: "Nitto Terra Grappler G2",
    slug: "nitto-terra-grappler-g2",
    description: "Premium all-terrain tire with excellent on-road comfort and off-road capability.",
    price: 299,
    compareAtPrice: 349,
    category: "Tires",
    brand: "Nitto",
    imageUrl: "/images/products/nitto-ridge-grappler-tire.png",
    inStock: true,
    stockQuantity: 32,
    featured: false,
    specifications: {
      size: "33x12.50R20",
      load_index: "114",
      speed_rating: "Q",
      tread_depth: "16/32\"",
      max_load: "2601 lbs",
      max_pressure: "65 PSI"
    }
  },
  {
    id: 11,
    name: "Nitto Trail Grappler",
    slug: "nitto-trail-grappler",
    description: "Aggressive mud-terrain tire with superior traction in extreme conditions.",
    price: 359,
    compareAtPrice: 419,
    category: "Tires",
    brand: "Nitto",
    imageUrl: "/images/products/nitto-ridge-grappler-tire.png",
    inStock: true,
    stockQuantity: 18,
    featured: false,
    specifications: {
      size: "37x12.50R20",
      load_index: "126",
      speed_rating: "Q",
      tread_depth: "20/32\"",
      max_load: "3748 lbs",
      max_pressure: "80 PSI"
    }
  },
  {
    id: 12,
    name: "BDS 6\" Lift Kit with FOX Shocks",
    slug: "bds-6-lift-kit-fox-shocks",
    description: "Complete 6-inch suspension lift kit with premium FOX shocks for ultimate performance.",
    price: 2899,
    compareAtPrice: 3299,
    category: "Suspension",
    brand: "BDS Suspension",
    imageUrl: "/images/products/bds-suspension-lift-kit.png",
    inStock: true,
    stockQuantity: 3,
    featured: true,
    specifications: {
      lift_height: "6 inches",
      shock_type: "FOX 2.0 Performance",
      spring_type: "Progressive Rate Coils",
      warranty: "No Limit Lifetime",
      installation_time: "8-10 hours",
      compatibility: "2015+ F-150"
    }
  },
  {
    id: 13,
    name: "BDS 4\" Lift Kit",
    slug: "bds-4-lift-kit",
    description: "Mid-level lift kit perfect for daily driving with improved off-road capability.",
    price: 2299,
    compareAtPrice: 2599,
    category: "Suspension",
    brand: "BDS Suspension",
    imageUrl: "/images/products/bds-suspension-lift-kit.png",
    inStock: true,
    stockQuantity: 5,
    featured: false,
    specifications: {
      lift_height: "4 inches",
      shock_type: "BDS NX2 Series",
      spring_type: "Progressive Rate Coils",
      warranty: "No Limit Lifetime",
      installation_time: "6-8 hours",
      compatibility: "2009+ F-150"
    }
  },
  {
    id: 14,
    name: "BDS 2\" Leveling Kit",
    slug: "bds-2-leveling-kit",
    description: "Simple leveling kit to eliminate factory rake and accommodate larger tires.",
    price: 599,
    compareAtPrice: 699,
    category: "Suspension",
    brand: "BDS Suspension",
    imageUrl: "/images/products/bds-suspension-lift-kit.png",
    inStock: true,
    stockQuantity: 12,
    featured: false,
    specifications: {
      lift_height: "2 inches front",
      shock_type: "Stock Compatible",
      spring_type: "Spacer Kit",
      warranty: "No Limit Lifetime",
      installation_time: "2-3 hours",
      compatibility: "2004+ F-150"
    }
  }
];

export const getProducts = () => staticProducts;
export const getProductBySlug = (slug: string) => staticProducts.find(p => p.slug === slug);
export const getProductsByCategory = (category: string) => staticProducts.filter(p => p.category === category);
export const getFeaturedProducts = () => staticProducts.filter(p => p.featured);

