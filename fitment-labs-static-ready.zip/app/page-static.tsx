import Link from 'next/link'
import { ProductCard } from '@/components/ProductCard'
import { PromoBanner } from '@/components/PromoBanner'
import { FitmentFilter } from '@/components/FitmentFilter'
import { getFeaturedProducts } from '@/lib/static-products'

export default function HomePage() {
  const featuredProducts = getFeaturedProducts()

  return (
    <div className="min-h-screen bg-black">
      <PromoBanner />
      
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url(/images/hero-truck.png)',
          }}
        >
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <div className="relative z-10 text-center text-white px-4 max-w-6xl mx-auto">
          <h1 className="text-6xl md:text-8xl font-bold mb-6 drop-shadow-2xl">
            Performance
            <span className="block text-chili-red">Redefined</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto drop-shadow-lg">
            Premium wheels, tires, and suspension for the ultimate automotive experience
          </p>
          
          {/* Fitment Filter */}
          <div className="mb-8">
            <FitmentFilter />
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/shop"
              className="bg-chili-red hover:bg-chili-red/90 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Shop Now
            </Link>
            <Link 
              href="/about"
              className="border-2 border-white text-white hover:bg-white hover:text-black px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Why Choose Fitment Labs</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              We deliver premium automotive components with unmatched quality and performance
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-chili-red rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Premium Quality</h3>
              <p className="text-gray-300">
                Only the finest materials and manufacturing processes for products that last
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-chili-red rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Performance Focused</h3>
              <p className="text-gray-300">
                Engineered for maximum performance in all conditions and applications
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-chili-red rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M12 2.25a9.75 9.75 0 100 19.5 9.75 9.75 0 000-19.5z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Expert Support</h3>
              <p className="text-gray-300">
                Professional guidance and support for all your fitment and performance needs
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Shop by Category */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Shop by Category</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Find the perfect components for your build from our curated selection of premium automotive parts.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Link href="/shop?category=Wheels" className="group">
              <div className="relative overflow-hidden rounded-lg bg-gray-800 aspect-video">
                <img 
                  src="/images/products/kg1-victor.jpg" 
                  alt="Wheels"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors">
                  <div className="absolute bottom-6 left-6">
                    <h3 className="text-2xl font-bold text-white mb-2">Wheels</h3>
                    <p className="text-gray-200">Premium forged and flow-formed wheels</p>
                  </div>
                </div>
              </div>
            </Link>
            
            <Link href="/shop?category=Tires" className="group">
              <div className="relative overflow-hidden rounded-lg bg-gray-800 aspect-video">
                <img 
                  src="/images/products/nitto-ridge-grappler-tire.png" 
                  alt="Tires"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors">
                  <div className="absolute bottom-6 left-6">
                    <h3 className="text-2xl font-bold text-white mb-2">Tires</h3>
                    <p className="text-gray-200">High-performance and all-terrain tires</p>
                  </div>
                </div>
              </div>
            </Link>
            
            <Link href="/shop?category=Suspension" className="group">
              <div className="relative overflow-hidden rounded-lg bg-gray-800 aspect-video">
                <img 
                  src="/images/products/bds-suspension-lift-kit.png" 
                  alt="Suspension"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors">
                  <div className="absolute bottom-6 left-6">
                    <h3 className="text-2xl font-bold text-white mb-2">Suspension</h3>
                    <p className="text-gray-200">Lift kits and performance suspension</p>
                  </div>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Featured Products</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Discover our most popular and highest-rated products
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link 
              href="/shop"
              className="bg-chili-red hover:bg-chili-red/90 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors"
            >
              View All Products
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

