import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { getProductBySlug, getProductsByCategory } from '@/lib/static-products'
import { PriceTag } from '@/components/PriceTag'
import { AddToCartButton } from '@/components/AddToCartButton'
import { ProductCard } from '@/components/ProductCard'
import { ArrowLeft, Package, Truck, Shield } from 'lucide-react'

interface ProductPageProps {
  params: {
    slug: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = getProductBySlug(params.slug)
  
  if (!product) {
    notFound()
  }

  const relatedProducts = getProductsByCategory(product.category)
  const otherProducts = relatedProducts.filter(p => p.id !== product.id).slice(0, 3)
  
  const specs = product.specifications
  const isInStock = product.inStock
  const isLowStock = product.stockQuantity <= 5

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm text-gray-400 mb-8">
          <Link href="/" className="hover:text-chili-red">Home</Link>
          <span>/</span>
          <Link href="/shop" className="hover:text-chili-red">Shop</Link>
          <span>/</span>
          <Link href={`/shop?category=${product.category}`} className="hover:text-chili-red">
            {product.category}
          </Link>
          <span>/</span>
          <span className="text-white font-medium">{product.name}</span>
        </nav>

        {/* Back Button */}
        <Link
          href="/shop"
          className="inline-flex items-center text-chili-red hover:text-chili-red/80 mb-8 font-medium"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Shop
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="space-y-4">
            <div className="relative aspect-square overflow-hidden rounded-lg bg-gray-800">
              <Image
                src={product.imageUrl}
                alt={product.name}
                fill
                className="object-cover"
                priority
              />
              
              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.featured && (
                  <span className="bg-chili-red text-white px-3 py-1 rounded-full text-sm font-semibold">Featured</span>
                )}
                {!isInStock && (
                  <span className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">Out of Stock</span>
                )}
                {isInStock && isLowStock && (
                  <span className="bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-semibold">Low Stock</span>
                )}
              </div>
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {/* Brand and Category */}
            <div className="flex items-center gap-3">
              <span className="bg-gray-800 text-gray-300 px-3 py-1 rounded-full text-sm">{product.category}</span>
              <span className="text-gray-400">by {product.brand}</span>
            </div>

            {/* Product Name */}
            <h1 className="text-3xl lg:text-4xl font-bold text-white leading-tight">
              {product.name}
            </h1>

            {/* Price */}
            <div className="space-y-2">
              <PriceTag 
                price={product.price} 
                compareAtPrice={product.compareAtPrice}
                className="text-2xl"
              />
            </div>

            {/* Description */}
            <p className="text-gray-300 text-lg leading-relaxed">
              {product.description}
            </p>

            {/* Stock Status */}
            <div className="flex items-center gap-2">
              <Package className="w-5 h-5 text-gray-400" />
              {isInStock ? (
                <span className="text-green-400 font-medium">
                  {product.stockQuantity} in stock
                </span>
              ) : (
                <span className="text-red-400 font-medium">
                  Out of stock
                </span>
              )}
            </div>

            {/* Add to Cart */}
            <div className="space-y-4">
              <AddToCartButton 
                product={product}
                disabled={!isInStock}
                className="w-full text-lg py-4 bg-chili-red hover:bg-chili-red/90 text-white rounded-lg font-semibold transition-colors"
              />
              
              {/* Features */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2 text-gray-400">
                  <Truck className="w-4 h-4" />
                  Free shipping over $500
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <Shield className="w-4 h-4" />
                  Manufacturer warranty
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Specifications */}
        {specs && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-white mb-6">Specifications</h2>
            <div className="bg-gray-900 rounded-lg p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(specs).map(([key, value]) => (
                  <div key={key} className="flex justify-between py-2 border-b border-gray-700 last:border-b-0">
                    <span className="font-medium text-white capitalize">
                      {key.replace(/([A-Z])/g, ' $1').replace(/_/g, ' ').trim()}:
                    </span>
                    <span className="text-gray-300">{value as string}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Related Products */}
        {otherProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-white mb-6">
              More {product.category}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {otherProducts.map((relatedProduct) => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

